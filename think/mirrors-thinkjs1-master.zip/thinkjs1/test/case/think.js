import test from 'ava';
import '../../lib/think';


test.serial('service method', t => {
  
});
