export default {
  title: '后台管理系统',
  debug: process.env.NODE_ENV !== 'production'
}
