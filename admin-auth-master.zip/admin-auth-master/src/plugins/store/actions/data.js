let res = [

  {
    name: '楼盘列表',
    url: '',
    children: [
      {
        name: '楼盘列表',
        url: '/estate'
      }
    ]
  }, {
    name: '楼盘相册',
    url: '',
    children: [
      {
        name: '楼盘相册',
        url: '/album'
      }
    ]
  },
  {
    name: '规划参数',
    url: '',
    children: [
      {
        name: '规划参数',
        url: '/parameter'
      }
    ]
  },
  {
    name: '地铁管理',
    url: '',
    children: [
      {
        name: '地铁管理',
        url: '/subway'
      }
    ]
  },

]
