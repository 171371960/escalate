import Vue from 'vue'
// tree grid
const ElTreeGrid = require('element-tree-grid')
Vue.component(ElTreeGrid.name, ElTreeGrid)
