<template>
  <div class="content">
    <h3>杭州快房传媒有限公司</h3>
    <ul>
      <li><i class="fa fa-arrow-circle-o-right mr5"></i>
        杭州快房传媒有限公司座落于钱江新城CBD核心商圈，是都市快报控股子公司，年营业额过亿，是都市快报全媒体阵营的重要一员。
      </li>
      <li><i class="fa fa-arrow-circle-o-right mr5"></i>
        公司设有媒体中心、运营中心、家居中心、网络中心、客服中心及宁波分中心，主要经营都市快报的房产广告及快房网的运营。都市快报的房产广告，位列浙江省房产投放量第一，最受房产商青睐。
      </li>
      <li><i class="fa fa-arrow-circle-o-right mr5"></i> 公司拥有一支年轻，活力四射，具有激情的团队。团队内有员工100多名，平均年龄29.1岁。</li>
      <li><i class="fa fa-arrow-circle-o-right mr5"></i>
        都市快报由杭州日报报业集团主办，于1999年1月1日创刊，是中国第一份四开异型加长报；全国发行，重点覆盖浙江省各地市县，是浙江省发行量最大的报纸。
      </li>
      <li><i class="fa fa-arrow-circle-o-right mr5"></i> 公司网址： http://www.kfw001.com/</li>
    </ul>
    <div class="footer-logo">
      <p class="text">本站由「杭州快房传媒有限公司」提供技术支持</p>
      <div class="logo">
        <img src="../../assets/images/logo.png" style="width:420px;height:80px">
      </div>
    </div>
  </div>
</template>

<script>
  export default {}
</script>

<style lang="scss" scoped>
  @import "Welcome";
</style>
